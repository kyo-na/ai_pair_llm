#include "engine/mini_llm/api/mini_llm_api.h"
#include <iostream>

MiniLLM::MiniLLM() {
    std::cout << "[MiniLLM] initialized (CPU)" << std::endl;
}

MiniLLMResult MiniLLM::forward(const MiniLLMTask&) {
    std::cout << "[MiniLLM] forward() called" << std::endl;

    MiniLLMResult r{};
    r.loss = 0.0f;
    return r;
}