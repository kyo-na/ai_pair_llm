#pragma once

struct Tensor4D {}; // 今はダミー

struct MiniLLMTask {
    Tensor4D* input;
    Tensor4D* target;
    bool training;
};

struct MiniLLMResult {
    float loss;
};

class MiniLLM {
public:
    MiniLLM();
    MiniLLMResult forward(const MiniLLMTask& task);
};